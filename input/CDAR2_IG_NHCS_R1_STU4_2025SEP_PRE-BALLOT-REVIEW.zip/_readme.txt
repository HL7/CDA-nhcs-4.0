Ballot title:                                    HL7 CDA® R2 Implementation Guide: National Health Care Surveys (NHCS), R1 STU Release 4 - US Realm
Edition:                                         Release 1 STU 4
Realm:                                           US Realm
Release status:                                  Standard for Trial Use (STU)
JIRA Specification key:                          nhcs
Version:                                         1.4.0
Errata identifier:                               n/a 
Ballot date:                                	 2025-09
Prepared by:                                     Public Health Work Group

Contents of the Ballot Package
====================================
This file:                                       _readme.txt 

-- STU -- 
CDAR2_IG_NHCS_R1_STU4_V1_Introductory_Material		                                Implementation Guide Introductory Material
CDAR2_IG_NHCS_R1_STU4_V2_Templates_and_Supporting                	                Implementation Guide Template Library and Supporting Material
                                
--- Sample files: Located in GitHub: https://github.com/HL7/CDA-nhcs-4.0 ---
examples/xml/CDAR2_IG_NHCS_R1_STU4_EDE.xml     		                        	CDA XML ED Sample
examples/html/CDAR2_IG_NHCS_R1_STU4_EDE.html		                                HTML rendering of ED Sample
examples/xml/CDAR2_IG_NHCS_R1_STU4_IPE.xml	      		                        CDA XML IP Sample
examples/html/CDAR2_IG_NHCS_R1_STU4_IPE.html 		                                HTML rendering of IP Sample
examples/xml/CDAR2_IG_NHCS_R1_STU4_OPE.xml			                        CDA XML OP Sample
examples/html/CDAR2_IG_NHCS_R1_STU4_OPE.html	 					HTML rendering of OP Sample

--- Transform/Stylesheet files ---
https://hl7.org/permalink/?CDAStyleSheet

---- Schema files ----
https://hl7.org/permalink/?CDAR2.0schema

-- Schematron Validation files Located in GitHub: https://github.com/HL7/CDA-nhcs-4.0 --
validation/CDAR2_IG_NHCS_R1_STU4.sch							Schematron for validation
validation/CDAR2_IG_NHCS_R1_STU4.xml							Schematron vocabulary file