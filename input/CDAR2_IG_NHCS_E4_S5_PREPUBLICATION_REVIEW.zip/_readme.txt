Publication title:                               HL7 CDA® R2 Implementation Guide: National Health Care Surveys (NHCS), Edition 4 - US Realm
Edition:                                         Edition 4 (5th STU Ballot)
Realm:                                           US Realm
Release status:                                  Standard for Trial Use (STU)
JIRA Specification key:                          nhcs
Version:                                         4.0.0
Errata identifier:                               n/a 
Publication date:                                2026-01
Prepared by:                                     Lantana Consulting Group / Public Health Work Group

Contents of the Ballot Package
====================================
This file:                                       _readme.txt 

-- STU -- 
CDAR2_IG_NHCS_E4_S5_V1_Introductory_Material		                                Implementation Guide Introductory Material
CDAR2_IG_NHCS_E4_S5_V2_Templates_and_Supporting                	                	Implementation Guide Template Library and Supporting Material
CDAR2_IG_NHCS_E4_S5_Mapping_Tables.xlsx							Mappings from survey data elements to CDA templates
                                
--- Sample files: Located in GitHub: https://github.com/HL7/CDA-nhcs-4.0 ---
examples/xml/CDAR2_IG_NHCS_E4_S5_EDE.xml     		                        	CDA XML Emergency Department Sample
examples/html/CDAR2_IG_NHCS_E4_S5_EDE.html		                                HTML rendering of Emergency Department Sample
examples/xml/CDAR2_IG_NHCS_E4_S5_IPE.xml	      		                        CDA XML Inpatient Sample
examples/html/CDAR2_IG_NHCS_E4_S5_IPE.html 		                                HTML rendering of Inpatient Sample
examples/xml/CDAR2_IG_NHCS_E4_S5_OPE.xml			                        CDA XML Outpatient Sample
examples/html/CDAR2_IG_NHCS_E4_S5_OPE.html	 					HTML rendering of Outpatient Sample

--- Transform/Stylesheet files ---
https://hl7.org/permalink/?CDAStyleSheet

---- Schema files ----
https://hl7.org/permalink/?CDAR2.0schema

-- Schematron Validation files Located in GitHub: https://github.com/HL7/CDA-nhcs-4.0 --
validation/CDAR2_IG_NHCS_E4_S5.sch							Schematron for validation
validation/CDAR2_IG_NHCS_E4_S5.xml							Schematron vocabulary file